echo "# AfghanKash" >> README.md
